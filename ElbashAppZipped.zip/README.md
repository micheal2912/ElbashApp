# אלבאש בדיקת משלוחים

אפליקציית ווב שמשווה בין צילומי המסך של המשלוחים לבין דוח התפוקה (PDF),
ומראה אילו שורות `מס' תעודה` בדוח עדיין ללא תמונה תואמת.

מעלים לדפדפן את תיקיית החודש — התמונות וקובץ ה-PDF — והאפליקציה קוראת את
`מספר משלוח` מכל תמונה (OCR בעברית), מצליבה מול עמודת `מס' תעודה` בדוח,
ומציגה טבלאות של **חסר / נמצא / בעיות / לפי תאריך** עם ייצוא לאקסל ול-CSV.

## הפעלה מקומית

נדרש Python 3.10 ומעלה, ומנוע Tesseract מותקן
(`winget install --id UB-Mannheim.TesseractOCR -e` בווינדוס,
`brew install tesseract` במק). מודל העברית כבר נמצא בתיקיית `tessdata/`.

```bash
pip install -r requirements.txt
python -m web.manage add mahmood      # יצירת משתמש; הסיסמה נשאלת בנפרד
python run_web.py                     # נפתח בדפדפן בכתובת http://127.0.0.1:8000
```

## העלאה לשרת

```bash
echo "ELBASH_SECRET_KEY=$(python -c 'import secrets;print(secrets.token_urlsafe(48))')" > .env
docker compose up -d --build
docker compose exec app python -m web.manage add mahmood
```

הקונטיינר מאזין על `127.0.0.1:8000` בלבד. יש להציב לפניו שרת שמטפל ב-HTTPS
(Caddy, nginx או Cloudflare Tunnel) — עוגיית ההתחברות מסומנת `Secure`,
כך שבחיבור HTTP רגיל מהרשת החיצונית ההתחברות לא תישמר.

### ניהול משתמשים

```bash
python -m web.manage add <שם> [--admin]
python -m web.manage passwd <שם>
python -m web.manage remove <שם>
python -m web.manage list
```

## משתני סביבה

| משתנה | ברירת מחדל | תפקיד |
| --- | --- | --- |
| `ELBASH_SECRET_KEY` | נוצר ונשמר בדיסק | חתימת עוגיית ההתחברות |
| `ELBASH_DATA_DIR` | `./data` | מסד המשתמשים והקבצים שהועלו |
| `ELBASH_SECURE_COOKIES` | `1` | יש לכבות רק לבדיקה מקומית ב-HTTP |
| `ELBASH_SESSION_HOURS` | `12` | תוקף ההתחברות |
| `ELBASH_MAX_FILES` | `5000` | מקסימום קבצים בהשוואה אחת |
| `ELBASH_MAX_FILE_MB` | `40` | גודל מרבי לקובץ בודד |
| `ELBASH_MAX_JOB_MB` | `4096` | גודל מרבי לכלל ההעלאה |
| `ELBASH_MAX_CONCURRENT_JOBS` | `1` | השוואות במקביל |
| `ELBASH_JOB_TTL_HOURS` | `24` | כעבור כמה זמן נמחקים הקבצים שהועלו |
| `TESSERACT_CMD` | חיפוש אוטומטי | נתיב מפורש למנוע ה-OCR |

## היכן נשמרים הנתונים

הכול נמצא בתיקייה אחת, `data/` (או `ELBASH_DATA_DIR`; בדוקר זו `/data`):

| נתיב | תוכן |
| --- | --- |
| `data/elbash.db` | המשתמשים. הסיסמה עצמה אינה נשמרת — רק `salt` אקראי ו-`scrypt` hash |
| `data/secret_key` | המפתח שחותם על עוגיית ההתחברות |
| `data/jobs/<id>/` | הקבצים שהועלו והייצואים שנוצרו, נמחקים אחרי `ELBASH_JOB_TTL_HOURS` |

תיקיית `data/` נמצאת ב-`.gitignore` ואסור להעלות אותה ל-git: היא מכילה את
מפתח החתימה, את גיבובי הסיסמאות ואת צילומי המשלוחים של הלקוחות.

## בדיקות

```bash
python tests/test_web_e2e.py    # העלאה, הרצה, הרשאות וייצוא מקצה לקצה
python run_cli.py <תיקייה>      # הרצת ההשוואה מהטרמינל, בלי ווב
```

## מבנה הפרויקט

| קובץ | תפקיד |
| --- | --- |
| `elbash/photos.py` | OCR לתמונות ואיתור `מספר משלוח` |
| `elbash/pdf_report.py` | קריאת הדוח וחילוץ עמודת `מס' תעודה` |
| `elbash/compare.py` | ההצלבה בין השניים |
| `elbash/export.py` | ייצוא לאקסל ול-CSV |
| `web/main.py` | נתיבי ה-HTTP |
| `web/jobs.py` | תור העבודות, ההעלאות וההתקדמות |
| `web/auth.py` | משתמשים וסיסמאות |

## הערות הנדסיות

שני השלבים הכבדים רצים במקביל, אבל לא באותה שיטה — זה נמדד, לא נוחש:

- **הדוח** מפוצל לקבוצות עמודים בין תהליכים (`ProcessPoolExecutor`).
  `pdfminer` מחזיק את ה-GIL, ולכן threads נמדדו כאיטיים יותר מריצה טורית
  (0.91x) בעוד תהליכים נתנו 5.3x.
- **התמונות** נקראות ב-threads, תמונה אחת לכל משימה. `tesseract` רץ כתהליך
  נפרד ומשחרר את ה-GIL, ולכן threads כבר מנצלים את כל הליבות; העברה
  לתהליכים או איגוד תמונות לקבוצות נמדדו כאיטיים יותר (0.99x ו-0.90x).

מספר העובדים נגזר מ-`os.cpu_count()` ומוגבל ל-16, כי מעבר לזה התהליכים
מתחרים על הליבות. ריצה אחת בכל רגע (`ELBASH_MAX_CONCURRENT_JOBS=1`) מכוונת:
השוואה אחת כבר מנצלת את כל המעבד.
